import pandas as pd
import numpy as np
import tensorflow as tf
from keras._tf_keras.keras.models import Sequential, Model
from keras._tf_keras.keras.layers import Input, Conv2D, MaxPooling2D, Flatten, Dense, Dropout, GlobalAveragePooling2D
from keras._tf_keras.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
import cv2
from keras._tf_keras.keras.applications import VGG16
from keras._tf_keras.keras.preprocessing.image import ImageDataGenerator
from keras._tf_keras.keras.callbacks import ReduceLROnPlateau

# Load dataset
data = pd.read_csv('age_gender.csv')

# Preprocess images
def preprocess_image(img_string):
    img = np.fromstring(img_string, sep=' ').reshape(48, 48).astype(np.uint8)
    img = cv2.resize(img, (64, 64))  # Resize images to 64x64
    img = np.stack((img,)*3, axis=-1)  # Convert grayscale to RGB
    return img

data['pixels'] = data['pixels'].apply(preprocess_image)

X = np.array(data['pixels'].tolist())
X = X / 255.0  # Normalize pixel values

# Prepare labels
age_labels = data['age'].values
gender_labels = to_categorical(data['gender'], num_classes=2)
ethnicity_labels = to_categorical(data['ethnicity'], num_classes=5)

# Split data into training and test sets
X_train, X_test, y_age_train, y_age_test, y_gender_train, y_gender_test, y_ethnicity_train, y_ethnicity_test = train_test_split(
    X, age_labels, gender_labels, ethnicity_labels, test_size=0.2, random_state=42)

# Data augmentation
datagen = ImageDataGenerator(
    rotation_range=10,
    width_shift_range=0.1,
    height_shift_range=0.1,
    shear_range=0.1,
    zoom_range=0.1,
    horizontal_flip=True,
    fill_mode='nearest'
)
datagen.fit(X_train)

# Load VGG16 base model
base_model = VGG16(weights='imagenet', include_top=False, input_shape=(64, 64, 3))
x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(512, activation='relu')(x)
x = Dropout(0.5)(x)

# Age prediction model
age_output = Dense(1, activation='linear', name='age_output')(x)
age_model = Model(inputs=base_model.input, outputs=age_output)
age_model.compile(optimizer='adam', loss='mse', metrics=['mae'])

# Gender prediction model
gender_output = Dense(2, activation='softmax', name='gender_output')(x)
gender_model = Model(inputs=base_model.input, outputs=gender_output)
gender_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Ethnicity prediction model
ethnicity_output = Dense(5, activation='softmax', name='ethnicity_output')(x)
ethnicity_model = Model(inputs=base_model.input, outputs=ethnicity_output)
ethnicity_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Make the base model layers non-trainable
for layer in base_model.layers:
    layer.trainable = False

# Learning rate reduction
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=3, min_lr=0.001)

# Train models
age_model.fit(datagen.flow(X_train, y_age_train, batch_size=32), validation_data=(X_test, y_age_test), epochs=20, callbacks=[reduce_lr])
gender_model.fit(datagen.flow(X_train, y_gender_train, batch_size=32), validation_data=(X_test, y_gender_test), epochs=20, callbacks=[reduce_lr])
ethnicity_model.fit(datagen.flow(X_train, y_ethnicity_train, batch_size=32), validation_data=(X_test, y_ethnicity_test), epochs=20, callbacks=[reduce_lr])

# Save models
age_model.save('age_model_2o.h5')
gender_model.save('gender_model_2o.h5')
ethnicity_model.save('ethnicity_model_2o.h5')