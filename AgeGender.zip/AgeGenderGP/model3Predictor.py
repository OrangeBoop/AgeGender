import numpy as np
from keras._tf_keras.keras.models import load_model
import cv2
import os

# Load the model
model = load_model('model4_o.h5', compile=False)

# Define the image preprocessing function
def preprocess_image(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, (64, 64))
    img = img / 255.0  # Normalize pixel values
    img = np.expand_dims(img, axis=0)  # Add batch dimension
    return img

# Directory containing test images
test_dir = 'Faces'

# Iterate over each image in the directory and make predictions
for image_name in os.listdir(test_dir):
    image_path = os.path.join(test_dir, image_name)
    if os.path.isfile(image_path):
        img = preprocess_image(image_path)
        
        # Make predictions
        predicted_age, predicted_gender_probs = model.predict(img)
        predicted_gender = 'Male' if predicted_gender_probs[0][0] < 0.5 else 'Female'
        
        # Print the predictions
        print(f"Image: {image_name}")
        print(f"Predicted Age: {predicted_age[0][0]}")
        print(f"Predicted Gender: {predicted_gender}")
        print()
