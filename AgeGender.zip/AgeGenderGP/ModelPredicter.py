import numpy as np
from keras._tf_keras.keras.models import load_model
import tensorflow as tf

from keras._tf_keras.keras.losses import MeanSquaredError
import cv2
import os

def mse(y_true, y_pred):
    return MeanSquaredError(y_true, y_pred)

def custom_predict(model, img):
    return model(img, training=False)

# Load the models
age_model = load_model('age_model_3o.h5', custom_objects={'mse': mse})
gender_model = load_model('gender_model_3o.h5')
ethnicity_model = load_model('ethnicity_model_3o.h5')

# Define the image preprocessing function
def preprocess_image(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, (64, 64))
    img = img / 255.0  # Normalize pixel values
    img = np.expand_dims(img, axis=0)  # Add batch dimension
    return img

# Directory containing test images
test_dir = 'Faces'

# Iterate over each image in the directory and make predictions
for image_name in os.listdir(test_dir):
    image_path = os.path.join(test_dir, image_name)
    if os.path.isfile(image_path):
        img = preprocess_image(image_path)
        
        # Make predictions
        predicted_age = age_model.predict(img)
        predicted_gender = gender_model.predict(img)
        predicted_ethnicity = ethnicity_model.predict(img)
        
        # Print the predictions
        print(f"Image: {image_name}")
        print(f"Predicted Age: {predicted_age[0][0]}")
        print(f"Predicted Gender: {'Male' if np.argmax(predicted_gender) == 0 else 'Female'}")
        print(f"Predicted Ethnicity: {np.argmax(predicted_ethnicity)}")
        print()