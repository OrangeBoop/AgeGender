import os
import numpy as np
import cv2
import tensorflow as tf
from keras._tf_keras.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from keras._tf_keras.keras.metrics import MeanSquaredError, CategoricalCrossentropy
import pickle

# Path to the UTKFace dataset
dataset_path = 'UTKFace'

# Initialize lists to hold the data and labels
images = []
ages = []
genders = []

# Load the data
for filename in os.listdir(dataset_path):
    if filename.endswith('.jpg'):
        # Extract age and gender from the filename
        age, gender, _ = filename.split('_')[:3]
        age = int(age)
        gender = int(gender)
        
        # Load the image
        img = cv2.imread(os.path.join(dataset_path, filename))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, (64, 64))
        
        images.append(img)
        ages.append(age)
        genders.append(gender)

# Convert lists to numpy arrays
images = np.array(images)
ages = np.array(ages)
genders = np.array(genders)

# Normalize the images
images = images / 255.0

# Convert genders to categorical (one-hot encoding)
genders = to_categorical(genders, num_classes=2)

# Split the data into training and testing sets
X_train, X_test, y_ages_train, y_ages_test, y_genders_train, y_genders_test = train_test_split(
    images, ages, genders, test_size=0.2, random_state=42)

# Define the model creation function
from keras._tf_keras.keras.models import Model, load_model
from keras._tf_keras.keras.layers import Input, Conv2D, MaxPooling2D, Flatten, Dense, Dropout

def create_model():
    input_layer = Input(shape=(64, 64, 3))

    # Convolutional layers
    x = Conv2D(32, (3, 3), activation='relu')(input_layer)
    x = MaxPooling2D((2, 2))(x)
    x = Conv2D(64, (3, 3), activation='relu')(x)
    x = MaxPooling2D((2, 2))(x)
    x = Conv2D(128, (3, 3), activation='relu')(x)
    x = MaxPooling2D((2, 2))(x)
    x = Flatten()(x)
    x = Dense(128, activation='relu')(x)
    x = Dropout(0.5)(x)

    # Age output
    age_output = Dense(1, name='age_output')(x)

    # Gender output
    gender_output = Dense(2, activation='softmax', name='gender_output')(x)

    # Create model
    model = Model(inputs=input_layer, outputs=[age_output, gender_output])
    
    model.compile(optimizer='adam',
                  loss={'age_output': 'mse', 'gender_output': 'categorical_crossentropy'},
                  metrics={'age_output': 'mae', 'gender_output': 'accuracy'})

    return model

# Check if the model file exists
custom_objects = {
    'mse': MeanSquaredError(),
    'categorical_crossentropy': CategoricalCrossentropy()
}

model_path = 'model4_o.h5'
history_path = 'training_history_model3.pkl'
if os.path.exists(model_path):
    model = load_model(model_path, custom_objects=custom_objects)
    if os.path.exists(history_path):
        with open(history_path, 'rb') as f:
            history = pickle.load(f)

        print("Available keys in history:", history.keys())   
        # Plotting the Training history 
        plt.figure(figsize=(12, 4))

        plt.subplot(1, 3, 1)
        plt.plot(history['loss'], label='Total Training Loss')
        plt.plot(history['val_loss'], label='Total Validation Loss')
        plt.title('Training and Validation Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()

        plt.subplot(1, 3, 3)
        plt.plot(history['gender_output_accuracy'], label='Gender Training Accuracy')
        plt.plot(history['val_gender_output_accuracy'], label='Gender Validation Accuracy')
        plt.title('Training and Validation Accuracy')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy')
        plt.legend()

        plt.subplot(1, 3, 2)
        plt.plot(history['age_output_mae'], label='Age Training MAE')
        plt.plot(history['val_age_output_mae'], label='Age Validation MAE')
        plt.title('Training and Validation MAE (Age)')
        plt.xlabel('Epoch')
        plt.ylabel('MAE')
        plt.legend()


        plt.savefig('training_history_model3.jpg')  # Save the plot as a .jpg file
        plt.show()
    else:
        print("Training history file not found. Retraining the model...")
        model = create_model()
        # Training the model 
        history = model.fit(
            X_train, 
            {'age_output': y_ages_train, 'gender_output': y_genders_train},
            validation_split=0.2,
            epochs=30,
            batch_size=32
        )
        with open(history_path, 'wb') as f:
            pickle.dump(history.history, f)
        model.save(model_path)
else:
    print("Model file not found. Please train the model first.")